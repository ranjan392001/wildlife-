<div class="footer-section">
				<div class="container">
					<div class="footer-top">
						<p>&copy; <?php echo date('Y')?> Wildlife Sanctuary Management System </p>
					</div>
				</div>
			</div>