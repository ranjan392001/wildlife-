<footer>
            <div class="footer-area">
                <p>Wildlife Sanctuary Management System </p>
            </div>
        </footer>